#include<cstdio>
bool p( int *prime, int n )
{
    for( int i = 0; prime[ i ] * prime[ i ] <= n; ++i )
        if( n % prime[ i ] == 0 )
            return false;
    return true;
}

int main()
{
    int a, b, c, d, r, prime[ 2820 ] = { 2 }, all = 0;
    bool isprime[ 25600 ] = { false, true, true };
    for( int i = 3; i < 25600; i += 2 )
        if( p( prime, i ) )
            prime[ ++all ] = i, isprime[ i ] = true;
    all = 0;
freopen("test","r",stdin);

    while( scanf( "%d.%d %d.%d", &a, &b, &c, &d ) != EOF )
    {
        int low = a*100 + b, high = c*100 + d;
        for( int i = low; i <= high; ++i )
            if( !isprime[ i ] )
            for( int p = 1; p < i && p*p*p <= i * 10000; ++p )
                if( i * 10000 % p == 0 )
                    for( int q = p; p*q*q <= i*10000; ++q )
                        if( i*10000/p % q == 0 )
                        {
                            r = i * 10000 / p / q;
                            if( p + q + r == i && p * q * r == i*10000 )
                                printf( "sum[ %d ] = %d, a[ %d ] = %d, b[ %d ] = %d, c[ %d ] = %d;\n", all, i, all, p, all, q, all, r ), ++all;
                        }
    }
    return 0;
}
